# project: p4
# submitter: Rjfischer
# partner: none


'''
data from: https://www.kaggle.com/aakashphadtare/concrete-data

an interesting graph could be the relationship between Superplasticizer and concrete strength


'''
from collections import OrderedDict
import pandas as pd
from flask import Flask, request, jsonify
import re

app = Flask(__name__)
n = 0
df = pd.read_csv("main.csv")
# if odd, A, if even B
# after 10, set most popular to final home page
version_count = 0
a_count = 0
b_count = 0


@app.route('/')
def home():
    global version_count
    if version_count < 10:
        with open("index.html") as f:
            html = f.read()
            if version_count % 2 == 0:
                # version A
                html = re.sub(r"donate.html(\?from=A|\?from=B|.)", "donate.html?from=A", html) 
                html = re.sub(r"background-color:(blue|red)", "background-color:blue", html)
                version_count += 1
            else:
                # version B
                html = re.sub(r"donate.html(\?from=A|\?from=B|.)", "donate.html?from=B", html)
                html = re.sub(r"background-color:(blue|red)", "background-color:red", html)
                version_count += 1
    else:
        with open("index.html") as f:
            html = f.read()
            if a_count > b_count:
                
                html = re.sub(r"donate.html(\?from=A|\?from=B|.)", "donate.html?from=A", html)
            else:
                
                html = re.sub(r"donate.html(\?from=A|\?from=B|.)", "donate.html?from=B", html)
                html = re.sub(r"background-color:(blue|red)", "background-color:red", html)
    return html

@app.route('/browse.html')
def browser_handler():
    df = pd.read_csv('main.csv')
    html = "<html><h1>{}</h1></html>".format("Browse")
    return html + df.to_html()

@app.route('/email', methods=["POST"])
def email():
    '''
    regex not tested on tester yet

    '''
    global n
    email = str(request.data, "utf-8")
    if re.match(r"^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$", email): # 1
        n = n+1
        with open("emails.txt", "a") as f: # open file in append mode
            f.write(email + "\n") # 2
        return jsonify("thanks, you're subscriber number {}!".format(n))
    return jsonify("the email {} is invalid, try again".format(email)) # 3

@app.route('/donate.html')
def donations_handler():
    global a_count
    global b_count
    if version_count<=10:
        if (version_count-1)%2==0:
            a_count+=1
        else:
            b_count+=1    
    
#     with open("index.html") as f:
#         index_html = f.read()
#         m = re.search(r"\?from=A", index_html)
#         if m:
#             a_count += 1
#         else:
#             b_count += 1

    html = """
    <html>
    <h1>Donate!</h1>
    <br>
    <p>give us your monneyy...now</p>
    </html>

    """
    return html

@app.route('/api.html')
def api():
    html="""
    <html>
    <h1>To get column information do this:</h1>
    <pre>/concretecols.json</pre>
    <h1>To get all concrete information do this:</h1>
    <pre>/concrete.json</pre>
    
    <h1>To get strong concrete information do this:</h1>
    <pre>/concrete.json?strength=50</pre>
    </html>
    """
    return html

@app.route('/concretecols.json')
def cols():
    d={}
    for col in df.columns:
        d[col]=str('float')
    return jsonify(d)

@app.route('/concrete.json')
def concrete():
    key=request.args.get("strength")
    L=[]
    if key != None:
        for row_index in range(len(df)):
            if float(df.iloc[row_index,-1])>=float(key):
                d={}
                for i in range(len(df.iloc[row_index])):
                    d[df.columns[i]]=str(df.iloc[row_index,i])
            
                L.append([row_index,d])
   
    else:
        for row_index in range(len(df)):
            d={}
            for i in range(len(df.iloc[row_index])):
                d[df.columns[i]]=str(df.iloc[row_index,i])
            L.append(d)
    return jsonify(L)


#    @app.route('/guess', methods=["POST"])
#def guess():
    #parts = request.get_data(as_text=True).split(",")
    
if __name__ == '__main__':
    app.run(host="0.0.0.0") # don't change this line!